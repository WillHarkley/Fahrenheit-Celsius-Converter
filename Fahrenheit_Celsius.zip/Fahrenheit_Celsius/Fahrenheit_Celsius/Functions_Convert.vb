﻿Public Class frmFunction
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        Dim ftemp, ctemp As Double
        ftemp = CDbl(txtFahrenheit.Text)
        ctemp = Convert(ftemp)
        txtCelsius.Text = ctemp

    End Sub

    Private Function Convert(t As Double) As Double
        Dim calculation As Double
        calculation = (5 / 9) * (t - 32)
        Return calculation
    End Function
End Class
