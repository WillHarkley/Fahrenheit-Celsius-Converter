﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFunction
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblF = New System.Windows.Forms.Label()
        Me.btnConvert = New System.Windows.Forms.Button()
        Me.lblC = New System.Windows.Forms.Label()
        Me.txtFahrenheit = New System.Windows.Forms.TextBox()
        Me.txtCelsius = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblF
        '
        Me.lblF.AutoSize = True
        Me.lblF.Location = New System.Drawing.Point(158, 37)
        Me.lblF.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblF.Name = "lblF"
        Me.lblF.Size = New System.Drawing.Size(121, 18)
        Me.lblF.TabIndex = 0
        Me.lblF.Text = "Temp-Fahrenheit"
        '
        'btnConvert
        '
        Me.btnConvert.Location = New System.Drawing.Point(383, 139)
        Me.btnConvert.Margin = New System.Windows.Forms.Padding(4)
        Me.btnConvert.Name = "btnConvert"
        Me.btnConvert.Size = New System.Drawing.Size(201, 80)
        Me.btnConvert.TabIndex = 2
        Me.btnConvert.Text = "Convert to Celsius"
        Me.btnConvert.UseVisualStyleBackColor = True
        '
        'lblC
        '
        Me.lblC.AutoSize = True
        Me.lblC.Location = New System.Drawing.Point(158, 329)
        Me.lblC.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblC.Name = "lblC"
        Me.lblC.Size = New System.Drawing.Size(94, 18)
        Me.lblC.TabIndex = 3
        Me.lblC.Text = "Temp-Celsius"
        '
        'txtFahrenheit
        '
        Me.txtFahrenheit.Location = New System.Drawing.Point(404, 34)
        Me.txtFahrenheit.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFahrenheit.Name = "txtFahrenheit"
        Me.txtFahrenheit.Size = New System.Drawing.Size(148, 25)
        Me.txtFahrenheit.TabIndex = 1
        '
        'txtCelsius
        '
        Me.txtCelsius.Location = New System.Drawing.Point(404, 322)
        Me.txtCelsius.Margin = New System.Windows.Forms.Padding(4)
        Me.txtCelsius.Name = "txtCelsius"
        Me.txtCelsius.ReadOnly = True
        Me.txtCelsius.Size = New System.Drawing.Size(148, 25)
        Me.txtCelsius.TabIndex = 3
        Me.txtCelsius.TabStop = False
        '
        'frmFunction
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 18.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightSalmon
        Me.ClientSize = New System.Drawing.Size(889, 420)
        Me.Controls.Add(Me.txtCelsius)
        Me.Controls.Add(Me.txtFahrenheit)
        Me.Controls.Add(Me.lblC)
        Me.Controls.Add(Me.btnConvert)
        Me.Controls.Add(Me.lblF)
        Me.Font = New System.Drawing.Font("Modern No. 20", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmFunction"
        Me.Text = "Function"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblF As Label
    Friend WithEvents btnConvert As Button
    Friend WithEvents lblC As Label
    Friend WithEvents txtFahrenheit As TextBox
    Friend WithEvents txtCelsius As TextBox
End Class
